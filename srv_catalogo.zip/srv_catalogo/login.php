<?php
/* login.php · Catálogo Maestro */
require __DIR__ . '/config.php';
require __DIR__ . '/includes/funciones.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['usuario'] ?? '');
    $p = $_POST['pass'] ?? '';
    $stmt = $conn->prepare(
        'SELECT id, nombre, pass_hash, rol FROM cm_usuarios WHERE usuario=? AND activo=1'
    );
    $stmt->bind_param('s', $u);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if ($res && password_verify($p, $res['pass_hash'])) {
        $_SESSION['cm_usuario'] = $u;
        $_SESSION['cm_nombre']  = $res['nombre'];
        $_SESSION['cm_rol']     = $res['rol'];
        header('Location: index.php');
        exit();
    }
    $error = 'Usuario o contraseña incorrectos.';
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Entrar · <?= APP_NAME ?></title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body class="login-body">
  <main class="login-card">
    <div class="login-mark">CM</div>
    <h1><?= APP_NAME ?></h1>
    <p class="muted">Gobernanza de datos y clasificación fiscal</p>
    <?php if ($error): ?>
      <div class="alerta"><?= h($error) ?></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
      <label>Usuario
        <input type="text" name="usuario" required autofocus>
      </label>
      <label>Contraseña
        <input type="password" name="pass" required>
      </label>
      <button type="submit">Entrar</button>
    </form>
    <footer class="muted"><?= FCA_COPY ?></footer>
  </main>
</body>
</html>
