<?php
/* pendientes.php · productos sin clasificar, agrupados por macro categoría */
$titulo = 'Pendientes';
$activo = 'pendientes';
require __DIR__ . '/includes/header.php';

$rows = $conn->query(
    "SELECT id_producto, nombre_estandar, presentacion, macro_categoria,
            code_prod_serv, unit_code, estatus_clasificacion
     FROM bd_ctrl_sat
     WHERE estatus_clasificacion <> 'CLASIFICADO'
     ORDER BY COALESCE(macro_categoria,'(sin categoría)'), nombre_estandar"
);

// agrupar en PHP
$grupos = [];
while ($f = $rows->fetch_assoc()) {
    $g = $f['macro_categoria'] ?: '(sin categoría)';
    $grupos[$g][] = $f;
}
?>
<h1>Pendientes de clasificación</h1>
<p class="muted">Agrupados por categoría para revisar y aprobar claves SAT en lote.</p>

<?php if (!$grupos): ?>
  <div class="alerta ok">Todo está clasificado. No hay pendientes.</div>
<?php else: foreach ($grupos as $cat => $items): ?>
  <section class="grupo">
    <h2><?= h($cat) ?> <span class="cuenta"><?= count($items) ?></span></h2>
    <div class="tabla-wrap">
    <table class="tabla compacta">
      <thead><tr>
        <th>Código</th><th>Nombre</th><th>Presentación</th>
        <th>Clave SAT</th><th>Unidad</th><th>Estado</th>
        <?php if (puede_editar()): ?><th></th><?php endif; ?>
      </tr></thead>
      <tbody>
      <?php foreach ($items as $f): ?>
        <tr>
          <td class="mono"><?= h($f['id_producto']) ?></td>
          <td><?= h($f['nombre_estandar']) ?></td>
          <td><?= h($f['presentacion']) ?: '—' ?></td>
          <td class="mono"><?= h($f['code_prod_serv']) ?: '—' ?></td>
          <td class="mono"><?= h($f['unit_code']) ?: '—' ?></td>
          <td><?= badge_estatus($f['estatus_clasificacion']) ?></td>
          <?php if (puede_editar()): ?>
            <td><a class="mini" href="editar.php?id=<?= urlencode($f['id_producto']) ?>">Clasificar</a></td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </section>
<?php endforeach; endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
