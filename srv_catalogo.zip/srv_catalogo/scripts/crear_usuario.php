<?php
/* =====================================================================
 * scripts/crear_usuario.php  ·  Catálogo Maestro
 * Crea o actualiza un usuario del mini-portal con contraseña hasheada.
 *
 * Uso (desde la carpeta del proyecto en la VPS):
 *   php scripts/crear_usuario.php <usuario> <"Nombre"> <password> <ROL>
 *   ROL = ADMIN | FISCAL | CONSULTA
 *
 * Ejemplo:
 *   php scripts/crear_usuario.php oscar "Oscar Jara" miClave123 FISCAL
 * ===================================================================== */

require __DIR__ . '/../config.php';

if ($argc < 5) {
    fwrite(STDERR, "Uso: php crear_usuario.php <usuario> <\"Nombre\"> <password> <ADMIN|FISCAL|CONSULTA>\n");
    exit(1);
}
[$_, $usuario, $nombre, $password, $rol] = $argv;
$rol = strtoupper($rol);
if (!in_array($rol, ['ADMIN', 'FISCAL', 'CONSULTA'], true)) {
    fwrite(STDERR, "Rol inválido: $rol\n");
    exit(1);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare(
    "INSERT INTO cm_usuarios (usuario, nombre, pass_hash, rol)
     VALUES (?,?,?,?)
     ON DUPLICATE KEY UPDATE nombre=VALUES(nombre), pass_hash=VALUES(pass_hash), rol=VALUES(rol)"
);
$stmt->bind_param('ssss', $usuario, $nombre, $hash, $rol);

if ($stmt->execute()) {
    echo "Usuario '$usuario' ($rol) listo.\n";
} else {
    fwrite(STDERR, "Error: {$conn->error}\n");
    exit(1);
}
