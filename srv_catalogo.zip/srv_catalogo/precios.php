<?php
/* precios.php · historial de precios (semáforo XELHUA) */
$titulo = 'Precios';
$activo = 'precios';
require __DIR__ . '/includes/header.php';

$id = trim($_GET['id'] ?? '');

// buscador de producto
$sugerencias = [];
if ($id === '' && isset($_GET['q'])) {
    $q = trim($_GET['q']);
    $stmt = $conn->prepare(
        "SELECT id_producto, nombre_estandar FROM bd_ctrl_sat
         WHERE nombre_estandar LIKE ? ORDER BY nombre_estandar LIMIT 20");
    $like = "%$q%"; $stmt->bind_param('s', $like);
    $stmt->execute(); $sugerencias = $stmt->get_result();
}

$historial = null; $prod = null;
if ($id !== '') {
    $stmt = $conn->prepare("SELECT id_producto, nombre_estandar FROM bd_ctrl_sat WHERE id_producto=?");
    $stmt->bind_param('s', $id); $stmt->execute();
    $prod = $stmt->get_result()->fetch_assoc();

    $stmt = $conn->prepare(
        "SELECT precio, tipo_precio, proveedor, fuente, vigente_desde
         FROM lista_precios WHERE id_producto=?
         ORDER BY vigente_desde DESC, id_precio DESC LIMIT 100");
    $stmt->bind_param('s', $id); $stmt->execute();
    $historial = $stmt->get_result();
}
?>
<h1>Historial de precios</h1>
<p class="muted">Cada cambio de precio queda registrado. El vigente es el más reciente.</p>

<form class="filtros" method="get">
  <input type="search" name="q" value="<?= h($_GET['q'] ?? '') ?>" placeholder="Buscar producto por nombre…">
  <button type="submit">Buscar</button>
</form>

<?php if ($sugerencias && $sugerencias->num_rows): ?>
  <ul class="sugerencias">
  <?php while ($s = $sugerencias->fetch_assoc()): ?>
    <li><a href="?id=<?= urlencode($s['id_producto']) ?>"><?= h($s['nombre_estandar']) ?></a></li>
  <?php endwhile; ?>
  </ul>
<?php endif; ?>

<?php if ($prod): ?>
  <h2><?= h($prod['nombre_estandar']) ?></h2>
  <div class="tabla-wrap">
  <table class="tabla">
    <thead><tr><th>Fecha</th><th>Tipo</th><th class="num">Precio</th><th>Proveedor</th><th>Fuente</th></tr></thead>
    <tbody>
    <?php if ($historial->num_rows === 0): ?>
      <tr><td colspan="5" class="vacio">Sin precios registrados.</td></tr>
    <?php else: while ($h = $historial->fetch_assoc()): ?>
      <tr>
        <td class="mono"><?= h($h['vigente_desde']) ?></td>
        <td><?= h($h['tipo_precio']) ?></td>
        <td class="num"><?= mxn((float)$h['precio']) ?></td>
        <td><?= h($h['proveedor']) ?: '—' ?></td>
        <td><?= h($h['fuente']) ?: '—' ?></td>
      </tr>
    <?php endwhile; endif; ?>
    </tbody>
  </table>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
