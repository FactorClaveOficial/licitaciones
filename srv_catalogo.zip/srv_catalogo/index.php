<?php
/* index.php · Panel */
$titulo = 'Panel';
$activo = 'inicio';
require __DIR__ . '/includes/header.php';

// conteos por estatus de clasificación
$conteos = ['CLASIFICADO'=>0, 'REVISAR'=>0, 'PENDIENTE'=>0];
$r = $conn->query("SELECT estatus_clasificacion e, COUNT(*) n FROM bd_ctrl_sat GROUP BY estatus_clasificacion");
while ($row = $r->fetch_assoc()) { $conteos[$row['e']] = (int)$row['n']; }
$total = array_sum($conteos);

// errores en la vista (productos no listos para facturar)
$con_error = 0;
$r2 = $conn->query("SELECT COUNT(*) n FROM vw_catalogo_productos WHERE Errores <> 'OK'");
if ($r2) { $con_error = (int)$r2->fetch_assoc()['n']; }

$pct = fn($n) => $total ? round(100*$n/$total, 1) : 0;
?>
<h1>Panel de gobernanza</h1>
<p class="muted">Estado de la clasificación fiscal del catálogo maestro.</p>

<section class="tarjetas">
  <div class="tarjeta">
    <span class="num"><?= number_format($total) ?></span>
    <span class="etq">Productos en el maestro</span>
  </div>
  <div class="tarjeta verde">
    <span class="num"><?= number_format($conteos['CLASIFICADO']) ?></span>
    <span class="etq">Clasificados · <?= $pct($conteos['CLASIFICADO']) ?>%</span>
  </div>
  <div class="tarjeta amarillo">
    <span class="num"><?= number_format($conteos['REVISAR']) ?></span>
    <span class="etq">Por revisar</span>
  </div>
  <div class="tarjeta rojo">
    <span class="num"><?= number_format($conteos['PENDIENTE']) ?></span>
    <span class="etq">Pendientes</span>
  </div>
  <div class="tarjeta">
    <span class="num"><?= number_format($con_error) ?></span>
    <span class="etq">No listos para facturar</span>
  </div>
</section>

<section class="barra-progreso" aria-label="Avance de clasificación">
  <div class="seg verde"   style="width:<?= $pct($conteos['CLASIFICADO']) ?>%"></div>
  <div class="seg amarillo" style="width:<?= $pct($conteos['REVISAR']) ?>%"></div>
  <div class="seg rojo"    style="width:<?= $pct($conteos['PENDIENTE']) ?>%"></div>
</section>

<div class="acciones">
  <a class="btn" href="catalogo.php">Ver catálogo completo</a>
  <a class="btn ghost" href="pendientes.php">Trabajar pendientes (<?= number_format($conteos['PENDIENTE']) ?>)</a>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
