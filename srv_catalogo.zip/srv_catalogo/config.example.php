<?php
/* =====================================================================
 * config.php  ·  Catálogo Maestro  ·  Factor Clave Analytics © 2026
 * ---------------------------------------------------------------------
 * Proyecto INDEPENDIENTE. Base de datos propia (catalogo_maestro),
 * separada del portal El Buen Sazón. Sirve en srv.factorclaveanalytics.com
 *
 * Copia este archivo a config.php y ajusta credenciales. NO subir a git.
 * ===================================================================== */

// ── Credenciales MySQL (ajustar en el servidor) ─────────────────────
$host = 'localhost';
$db   = 'catalogo_maestro';
$user = 'cm_app';            // usuario dedicado, NO root
$pass = 'CAMBIAR_EN_PROD';
$port = 3306;

// ── Conexión MySQLi ─────────────────────────────────────────────────
$conn = new mysqli($host, $user, $pass, $db, $port);
if ($conn->connect_error) {
    http_response_code(500);
    die('Sin conexión a base de datos.');
}
$conn->set_charset('utf8mb4');

// ── Constantes de la app ────────────────────────────────────────────
define('APP_NAME', 'Catálogo Maestro');
define('FCA_COPY', 'Factor Clave Analytics © 2026');
define('APP_VER',  '1.0');

// ── Sesión ──────────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
