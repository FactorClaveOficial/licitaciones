<?php
/* =====================================================================
 * includes/funciones.php  ·  Catálogo Maestro
 * Helpers de autenticación, badges y formato. Independiente del portal.
 * ===================================================================== */

/** Exige sesión iniciada; si no, manda a login. */
function requiere_login(): void {
    if (empty($_SESSION['cm_usuario'])) {
        header('Location: login.php');
        exit();
    }
}

/** Exige uno de los roles dados. Roles: ADMIN, FISCAL, CONSULTA. */
function requiere_rol(array $roles): void {
    requiere_login();
    if (!in_array($_SESSION['cm_rol'] ?? '', $roles, true)) {
        http_response_code(403);
        die('Sin permiso para esta sección.');
    }
}

/** ¿El rol actual puede editar la clasificación fiscal? */
function puede_editar(): bool {
    return in_array($_SESSION['cm_rol'] ?? '', ['ADMIN', 'FISCAL'], true);
}

/** Badge HTML para el estatus de clasificación. */
function badge_estatus(string $estatus): string {
    $map = [
        'CLASIFICADO' => ['#1b9e5a', 'Clasificado'],
        'REVISAR'     => ['#d98a00', 'Revisar'],
        'PENDIENTE'   => ['#c0392b', 'Pendiente'],
    ];
    [$color, $label] = $map[$estatus] ?? ['#777', $estatus];
    return "<span class='badge' style='background:$color'>$label</span>";
}

/** Badge para la columna Errores de la vista. */
function badge_error(string $error): string {
    $ok = ($error === 'OK');
    $color = $ok ? '#1b9e5a' : '#c0392b';
    $txt = htmlspecialchars($error);
    return "<span class='badge' style='background:$color'>$txt</span>";
}

/** Formatea dinero MXN. */
function mxn(?float $v): string {
    return $v === null ? '—' : '$' . number_format($v, 2);
}

/** Escape corto. */
function h(?string $s): string {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

/** Tasa como porcentaje legible. */
function pct(?float $v): string {
    return $v === null ? '—' : rtrim(rtrim(number_format($v * 100, 2), '0'), '.') . '%';
}
