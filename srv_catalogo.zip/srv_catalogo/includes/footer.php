</main>
<footer class="pie"><?= FCA_COPY ?> · v<?= APP_VER ?></footer>
</body>
</html>
