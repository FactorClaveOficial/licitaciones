<?php
/* includes/header.php · layout compartido */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/funciones.php';
requiere_login();
$rol = $_SESSION['cm_rol'] ?? '';
$activo = $activo ?? '';
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= isset($titulo) ? h($titulo).' · ' : '' ?><?= APP_NAME ?></title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<header class="topbar">
  <div class="brand"><span class="brand-mark">CM</span> <?= APP_NAME ?></div>
  <nav>
    <a href="index.php"        class="<?= $activo==='inicio'?'on':'' ?>">Panel</a>
    <a href="catalogo.php"     class="<?= $activo==='catalogo'?'on':'' ?>">Catálogo</a>
    <a href="pendientes.php"   class="<?= $activo==='pendientes'?'on':'' ?>">Pendientes</a>
    <a href="precios.php"      class="<?= $activo==='precios'?'on':'' ?>">Precios</a>
  </nav>
  <div class="usuario">
    <span><?= h($_SESSION['cm_nombre']) ?> · <?= h($rol) ?></span>
    <a href="logout.php" class="salir">Salir</a>
  </div>
</header>
<main class="contenido">
