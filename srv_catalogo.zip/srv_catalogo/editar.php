<?php
/* editar.php · clasificación fiscal de un SKU (ADMIN/FISCAL) */
$titulo = 'Editar producto';
$activo = 'catalogo';
require __DIR__ . '/includes/header.php';
requiere_rol(['ADMIN', 'FISCAL']);

$id = $_GET['id'] ?? '';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = $_POST['id'];
    $code        = trim($_POST['code_prod_serv']) ?: null;
    $unit        = trim($_POST['unit_code']) ?: null;
    $objeto      = $_POST['objeto_imp'];
    $tasa_iva    = (float)$_POST['tasa_iva'];
    $ieps_pct    = (float)$_POST['ieps_pct'];
    $ieps_cuota  = (float)$_POST['ieps_cuota_litro'];
    $estatus     = $_POST['estatus_clasificacion'];

    $stmt = $conn->prepare(
        "UPDATE bd_ctrl_sat SET code_prod_serv=?, unit_code=?, objeto_imp=?,
                tasa_iva=?, ieps_pct=?, ieps_cuota_litro=?, estatus_clasificacion=?
         WHERE id_producto=?"
    );
    $stmt->bind_param('sssdddss', $code, $unit, $objeto,
        $tasa_iva, $ieps_pct, $ieps_cuota, $estatus, $id);
    $msg = $stmt->execute() ? 'Cambios guardados.' : 'Error al guardar.';
}

// cargar producto
$stmt = $conn->prepare("SELECT * FROM bd_ctrl_sat WHERE id_producto=?");
$stmt->bind_param('s', $id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if (!$p) { echo "<p class='alerta'>Producto no encontrado.</p>"; require __DIR__.'/includes/footer.php'; exit; }

// catálogos para selects
$unidades = $conn->query("SELECT clave, nombre FROM cat_unidad ORDER BY clave");
$objetos  = $conn->query("SELECT clave, descripcion FROM cat_objeto_imp ORDER BY clave");
?>
<a class="volver" href="catalogo.php">‹ Volver al catálogo</a>
<h1><?= h($p['nombre_estandar']) ?></h1>
<p class="muted mono"><?= h($p['id_producto']) ?> · <?= h($p['presentacion']) ?></p>
<?php if ($msg): ?><div class="alerta ok"><?= h($msg) ?></div><?php endif; ?>

<form method="post" class="form-fiscal">
  <input type="hidden" name="id" value="<?= h($p['id_producto']) ?>">

  <label>Clave producto/servicio SAT (8 díg.)
    <input type="text" name="code_prod_serv" maxlength="8" class="mono"
           value="<?= h($p['code_prod_serv']) ?>" pattern="\d{8}"
           placeholder="50131800">
  </label>

  <label>Unidad (UnitCode)
    <select name="unit_code">
      <option value="">— sin asignar —</option>
      <?php while ($u = $unidades->fetch_assoc()): ?>
        <option value="<?= h($u['clave']) ?>" <?= $p['unit_code']===$u['clave']?'selected':'' ?>>
          <?= h($u['clave']) ?> · <?= h($u['nombre']) ?>
        </option>
      <?php endwhile; ?>
    </select>
  </label>

  <label>Objeto de impuesto
    <select name="objeto_imp">
      <?php while ($o = $objetos->fetch_assoc()): ?>
        <option value="<?= h($o['clave']) ?>" <?= $p['objeto_imp']===$o['clave']?'selected':'' ?>>
          <?= h($o['clave']) ?> · <?= h($o['descripcion']) ?>
        </option>
      <?php endwhile; ?>
    </select>
  </label>

  <div class="fila3">
    <label>Tasa IVA
      <select name="tasa_iva">
        <option value="0.16" <?= (float)$p['tasa_iva']===0.16?'selected':'' ?>>16%</option>
        <option value="0.00" <?= (float)$p['tasa_iva']===0.0?'selected':'' ?>>0% (canasta básica)</option>
      </select>
    </label>
    <label>IEPS %
      <input type="number" step="0.01" min="0" max="1" name="ieps_pct"
             value="<?= h((string)$p['ieps_pct']) ?>" placeholder="0.08">
    </label>
    <label>IEPS cuota $/L
      <input type="number" step="0.0001" min="0" name="ieps_cuota_litro"
             value="<?= h((string)$p['ieps_cuota_litro']) ?>" placeholder="1.6451">
    </label>
  </div>

  <label>Estatus de clasificación
    <select name="estatus_clasificacion">
      <option value="PENDIENTE"   <?= $p['estatus_clasificacion']==='PENDIENTE'?'selected':'' ?>>Pendiente</option>
      <option value="REVISAR"     <?= $p['estatus_clasificacion']==='REVISAR'?'selected':'' ?>>Revisar</option>
      <option value="CLASIFICADO" <?= $p['estatus_clasificacion']==='CLASIFICADO'?'selected':'' ?>>Clasificado</option>
    </select>
  </label>

  <button type="submit">Guardar clasificación</button>
</form>

<?php require __DIR__ . '/includes/footer.php'; ?>
